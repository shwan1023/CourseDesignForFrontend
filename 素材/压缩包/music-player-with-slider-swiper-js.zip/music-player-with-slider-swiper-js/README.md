# Music Player with Slider | Swiper JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/ecemgo/pen/vYPadZz](https://codepen.io/ecemgo/pen/vYPadZz).

In this pen, every image is paired with its unique music and it has image reflection. As you navigate through the images using the backward and forward buttons, synchronized music plays with the visual transitions. The music player is completed with a slider by Swiper JS.

Inspired by https://dribbble.com/shots/5455156-Car-HMI-assistant-Album-switching