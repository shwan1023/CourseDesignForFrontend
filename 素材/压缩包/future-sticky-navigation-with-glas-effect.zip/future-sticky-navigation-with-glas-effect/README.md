# Future Sticky Navigation with Glas Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/codesuey/pen/abPEyjo](https://codepen.io/codesuey/pen/abPEyjo).

A really cool modern sticky navigation with a glass effect and a menu button. Only Vanilla JS and (S)CSS.